package com.example.MemoryMatchingGame;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class ImageLoadTask extends AsyncTask<String, Integer, String> {
    private ICallback callback = null;


    public ImageLoadTask(ICallback callback) {
        this.callback = callback;
    }

    @Override
    protected String doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                URLConnection con = null;
                con = url.openConnection();
                String encoding = con.getContentEncoding();
                if (encoding == null) {
                    encoding = "ISO-8859-1";
                }
                BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), encoding));
                StringBuilder sb = new StringBuilder();
                try {
                    String s;
                    while ((s = r.readLine()) != null) {
                        sb.append(s);
                        sb.append("\n");
                    }
                } finally {
                    r.close();
                }
                String html = sb.toString();
                return html;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }



    @Override
    protected void onProgressUpdate(Integer... values) {
//        if (callback != null)
//            callback.getSourceCodeProgress(values[0]);

    }

    @Override
    protected void onPostExecute(String html) {

        if(callback!=null){
            callback.onProcessFinish(html);
        }

    }

    public interface ICallback {
        void onProcessFinish(String output);
    }




}